package models;

public class Vendedor extends Funcionario {

	public Vendedor(String nome, double salarioBasico) {
		super(nome, salarioBasico);
		// TODO Auto-generated constructor stub
	}

	private double totalDeVendas;

	public Vendedor(String nome, double salarioBasico, double totalDeVendas) {
		super(nome, salarioBasico);
		this.totalDeVendas = totalDeVendas;
	}
	
	public double salarioFinal() {
		return getSalarioBasico() + (totalDeVendas * 0.15);
	}

	public double getTotalDeVendas() {
		return totalDeVendas;
	}

	public void setTotalDeVendas(double totalDeVendas) {
		this.totalDeVendas = totalDeVendas;
	}
	
	@Override
	public String toString() {
		return "Vendedor [totalDeVendas=" + totalDeVendas + ", salarioFinal()=" + salarioFinal()
				+ ", getTotalDeVendas()=" + getTotalDeVendas() + ", toString()=" + super.toString() + ", getNome()="
				+ getNome() + ", getSalarioBasico()=" + getSalarioBasico() + ", getClass()=" + getClass()
				+ ", hashCode()=" + hashCode() + "]";
	}

}
