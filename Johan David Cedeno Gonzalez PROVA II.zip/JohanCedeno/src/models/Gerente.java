package models;


public class Gerente extends Funcionario {
	private String setorQueGerencia;
	private double gratificacao;
	
	public Gerente(String nome, double salarioBasico, String setorGerenciado, double gratificacao) {
		super(nome,salarioBasico);
		this.setorQueGerencia = setorGerenciado;
		this.gratificacao = gratificacao;
	}
	
	public double salarioFinal(double gratificacao) {
		return +gratificacao;
	}

	public String getSetorQueGerencia() {
		return setorQueGerencia;
	}

	public void setSetorQueGerencia(String setorQueGerencia) {
		this.setorQueGerencia = setorQueGerencia;
	}

	public double getGratificacao() {
		return gratificacao;
	}

	public void setGratificacao(double gratificacao) {
		this.gratificacao = gratificacao;
	}

	@Override
	public String toString() {
		return "Gerente [setorQueGerencia=" + setorQueGerencia + ", gratificacao=" + gratificacao
				+ ", getSetorQueGerencia()=" + getSetorQueGerencia() + ", getGratificacao()=" + getGratificacao()
				+ ", salarioFinal()=" + salarioFinal() + ", toString()=" + super.toString() + ", getNome()=" + getNome()
				+ ", getSalarioBasico()=" + getSalarioBasico() + ", getClass()=" + getClass() + ", hashCode()="
				+ hashCode() + "]";
	}
	
	

}
