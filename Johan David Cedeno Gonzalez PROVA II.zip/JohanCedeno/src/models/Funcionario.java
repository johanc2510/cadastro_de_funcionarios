package models;

public class Funcionario {
    private String nome;
    private double salarioBasico;


    public Funcionario(String nome, double salarioBasico) {
        this.nome = nome;
        this.salarioBasico = salarioBasico;
    }

    //calcula o salário final
    public double salarioFinal() {
        return salarioBasico;
    }

    @Override
    public String toString() {
        return "Funcionario [nome=" + nome + ", salarioBasico=" + salarioBasico + "]";
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public double getSalarioBasico() {
        return salarioBasico;
    }

    public void setSalarioBasico(double salarioBasico) {
        this.salarioBasico = salarioBasico;
    }
}
