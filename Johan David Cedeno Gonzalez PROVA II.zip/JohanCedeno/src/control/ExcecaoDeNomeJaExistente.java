package control;

// Exceção para nomes duplicados
public class ExcecaoDeNomeJaExistente extends Exception {

    public ExcecaoDeNomeJaExistente() {
        super("Nome já existente na lista.");
    }

    public ExcecaoDeNomeJaExistente(String mensagem) {
        super(mensagem);
    }
}
