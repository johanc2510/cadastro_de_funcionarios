package view;

import control.ExcecaoDeNomeJaExistente;
import models.Funcionario;
import java.util.ArrayList;

public class ListaDeFuncionario {
    private ArrayList<Funcionario> listaFunc = new ArrayList<>();

    // Adicionar funcionário a lista
    public void incluir(Funcionario funcionario) throws ExcecaoDeNomeJaExistente {
        for (Funcionario f : listaFunc) {
            if (f.getNome().equals(funcionario.getNome())) {
                throw new ExcecaoDeNomeJaExistente("Funcionário com nome já existente: " + funcionario.getNome());
            }
        }
        listaFunc.add(funcionario);
    }

    // Funcionrios com salario acima de determinado valor
    public ListaDeFuncionario salarioAcima(double valor) {
        ListaDeFuncionario acima = new ListaDeFuncionario();
        for (Funcionario f : listaFunc) {
            if (f.salarioFinal() > valor) {
            }
        }
        return acima;
    }

    // Verifica se a lista esta vazia
    public boolean vazia() {
        return listaFunc.isEmpty();
    }

    // Tamanho da lista
    public int tamanho() {
        return listaFunc.size();
    }

    // Obtem funcionario por idice
    public Funcionario get(int indice) {
        if (indice < 0 || indice >= listaFunc.size()) {
            throw new IndexOutOfBoundsException("Índice inválido: " + indice);
        }
        return listaFunc.get(indice);
    }
}
