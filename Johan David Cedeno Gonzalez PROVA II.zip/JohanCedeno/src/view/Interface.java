package view;

import control.ExcecaoDeNomeJaExistente;
import models.Funcionario;
import java.util.Scanner;

public class Interface {
    private ListaDeFuncionario listaDeFuncionario = new ListaDeFuncionario();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Interface interfaceMenu = new Interface();

        System.out.println("1- Incluir funcionário na lista");
        System.out.println("2- Consultar funcionários com salário acima de determinado valor");

        int escolha;
        do {
            System.out.print("Escolha uma opção: ");
            escolha = scanner.nextInt();

            switch (escolha) {
                case 1:
                    try {
                        interfaceMenu.incluirFuncionario(scanner);
                    } catch (ExcecaoDeNomeJaExistente e) {
                        System.out.println("Erro: " + e.getMessage());
                    }
                    break;
                case 2:
                    interfaceMenu.consultarSalarioAcima(scanner);
                    
                    break;
            }
        } while (escolha != 3);

        scanner.close();
    }

    private void incluirFuncionario(Scanner scanner) throws ExcecaoDeNomeJaExistente {
        scanner.nextLine();
        System.out.print("Digite o nome do funcionário: ");
        String nome = scanner.nextLine();

        System.out.print("Digite o salário básico do funcionário: ");
        double salarioBasico = scanner.nextDouble();

        Funcionario funcionario = new Funcionario(nome, salarioBasico);

        System.out.println("Funcionário incluído com sucesso!");
    }

    private void consultarSalarioAcima(Scanner scanner) {
        scanner.nextLine();

        System.out.print("Digite o valor do salário: ");
        double valor = scanner.nextDouble();

        ListaDeFuncionario funcionariosAcima = listaDeFuncionario.salarioAcima(valor);

    
        System.out.println("Funcionários com salário acima de " + valor + ":");
        for (int i = 0; i < funcionariosAcima.tamanho(); i++) {
            System.out.println(funcionariosAcima.get(i));
        }
    }
}
