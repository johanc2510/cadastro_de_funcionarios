package view;

import control.ExcecaoDeNomeJaExistente;
import models.Funcionario;

public interface Lista {
	
	public void incluir(Funcionario funcionario) throws ExcecaoDeNomeJaExistente;
	
	public Lista salarioAcima(double valor);
	
	public boolean vazia();
	
	public int tamanho ();
	
	public Funcionario get (int indice);
}
